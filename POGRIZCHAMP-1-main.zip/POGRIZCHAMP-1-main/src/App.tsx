/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { FlipbookConfig, DEFAULT_CONFIG } from './types/flipbook';
import { BrandingConfig, DEFAULT_BRANDING } from './types/branding';
import { Navbar } from './components/Navbar';
import { FlipbookViewer } from './components/FlipbookViewer';
import { DocumentInfo } from './components/DocumentInfo';
import { ShareModal } from './components/ShareModal';
import { EmbedConfigModal } from './components/EmbedConfigModal';
import { BrandingModal } from './components/BrandingModal';
import { KeyboardShortcutsModal } from './components/KeyboardShortcutsModal';
import { Footer } from './components/Footer';

export default function App() {
  // Flipbook publication config
  const [config, setConfig] = useState<FlipbookConfig>(() => {
    try {
      const saved = localStorage.getItem('neuron_flipbook_config_v1');
      if (saved) {
        return { ...DEFAULT_CONFIG, ...JSON.parse(saved) };
      }
    } catch {
      // ignore
    }
    return DEFAULT_CONFIG;
  });

  // Custom branding (Neuron Flipbook, STEC Logo, Primary Blue, Secondary Maroon Red)
  const [branding, setBranding] = useState<BrandingConfig>(() => {
    try {
      const saved = localStorage.getItem('neuron_flipbook_branding_v1');
      if (saved) {
        return { ...DEFAULT_BRANDING, ...JSON.parse(saved) };
      }
    } catch {
      // ignore
    }
    return DEFAULT_BRANDING;
  });

  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [isConfigOpen, setIsConfigOpen] = useState(false);
  const [isBrandingOpen, setIsBrandingOpen] = useState(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState(false);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('neuron_flipbook_config_v1', JSON.stringify(config));
    } catch {
      // ignore
    }
  }, [config]);

  useEffect(() => {
    try {
      localStorage.setItem('neuron_flipbook_branding_v1', JSON.stringify(branding));
    } catch {
      // ignore
    }
  }, [branding]);

  const handleUpdateConfig = useCallback((updated: Partial<FlipbookConfig>) => {
    setConfig((prev) => ({ ...prev, ...updated }));
  }, []);

  const handleUpdateBranding = useCallback((updated: Partial<BrandingConfig>) => {
    setBranding((prev) => ({ ...prev, ...updated }));
  }, []);

  const handleToggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => {
        setIsFullscreen(true);
      }).catch(() => {
        setIsFullscreen((prev) => !prev);
      });
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().then(() => {
          setIsFullscreen(false);
        }).catch(() => {
          setIsFullscreen(false);
        });
      }
    }
  }, []);

  // Listen for fullscreen change events from browser
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (e.key === 'f' || e.key === 'F') {
        e.preventDefault();
        handleToggleFullscreen();
      } else if (e.key === '?') {
        e.preventDefault();
        setIsShortcutsOpen(true);
      }
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleToggleFullscreen]);

  const hasActiveFlipbook = Boolean(config.embedUrl || config.embedHtml);

  return (
    <div className="min-h-screen bg-[#FAF9F6] text-[#1A1A1A] flex flex-col font-serif selection:bg-[#1A1A1A] selection:text-white">
      {/* Top Curated Header with Logo & Brand Colors */}
      <Navbar
        config={config}
        branding={branding}
        isFullscreen={isFullscreen}
        onToggleFullscreen={handleToggleFullscreen}
        onOpenShare={() => setIsShareOpen(true)}
        onOpenConfig={() => setIsConfigOpen(true)}
        onOpenBranding={() => setIsBrandingOpen(true)}
        onOpenShortcuts={() => setIsShortcutsOpen(true)}
        hasActiveFlipbook={hasActiveFlipbook}
      />

      {/* Main Flipbook Showcase Viewer Area */}
      <main className="flex-1">
        <FlipbookViewer
          config={config}
          branding={branding}
          onUpdateConfig={handleUpdateConfig}
          onOpenEmbedModal={() => setIsConfigOpen(true)}
          onOpenBrandingModal={() => setIsBrandingOpen(true)}
          isFullscreen={isFullscreen}
          onToggleFullscreen={handleToggleFullscreen}
        />

        {/* Detailed Publication Information & Specifications */}
        {!isFullscreen && (
          <DocumentInfo
            config={config}
            branding={branding}
            onOpenShare={() => setIsShareOpen(true)}
            onOpenEmbedModal={() => setIsConfigOpen(true)}
            onOpenBrandingModal={() => setIsBrandingOpen(true)}
          />
        )}
      </main>

      {/* Editorial Colophon Footer */}
      {!isFullscreen && (
        <Footer
          config={config}
          branding={branding}
          onOpenEmbedModal={() => setIsConfigOpen(true)}
          onOpenBrandingModal={() => setIsBrandingOpen(true)}
        />
      )}

      {/* Share Modal */}
      <ShareModal
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
        config={config}
      />

      {/* Embed & Configuration Modal */}
      <EmbedConfigModal
        isOpen={isConfigOpen}
        onClose={() => setIsConfigOpen(false)}
        config={config}
        onSave={handleUpdateConfig}
      />

      {/* Custom Branding & Logo Suite Modal */}
      <BrandingModal
        isOpen={isBrandingOpen}
        onClose={() => setIsBrandingOpen(false)}
        branding={branding}
        onSave={handleUpdateBranding}
      />

      {/* Keyboard Shortcuts & Help Modal */}
      <KeyboardShortcutsModal
        isOpen={isShortcutsOpen}
        onClose={() => setIsShortcutsOpen(false)}
      />
    </div>
  );
}
